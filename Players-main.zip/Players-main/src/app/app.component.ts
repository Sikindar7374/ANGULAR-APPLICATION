import { Component } from '@angular/core';
// import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './homepage.html',
  styleUrls: ['./app.component.css']
})


export class AppComponent {
  title = 'myapplication';
}